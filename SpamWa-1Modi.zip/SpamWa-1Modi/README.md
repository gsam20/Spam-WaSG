# SpamWa
```
$ pkg install python
$ pkg install git
$ python3 -m pip install requests
$ git clone https://github.com/sandiwijayani1/SpamWa-1
$ cd SpamWa-1
$ python3 spam.py
```
